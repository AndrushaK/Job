<form method="POST">
<input type="text" placeholder="Логін" name="login" id="" ><br>
<input type="text" placeholder="Пароль" name="password1" id="" ><br>
<input type="text" placeholder="Повторіть пароль" name="password2" id="" ><br>
<input type="text" placeholder="Електронна пошта" name="email" id="" ><br>
<input type="submit" id="button_registration" value="Реєстрація">
</form>