            <ul>
                <li><a class="active" href="#">Дім</a></li>
                <li><a href="#">Люди</a></li>
                <li><a href="#">Телефони</a></li>
                <li><a href="#">Довідка</a></li>
            </ul>
            