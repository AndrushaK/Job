<div class="box">
    <h3>Додати користувача</h3>
            <div id="left_input"  align=center>
            <input type="text" placeholder="Ім'я" name="first_name" id="first_name"><br><br>    
            <input type="text" placeholder="Прізвище" name="second_name" id="second_name" ><br><br>
            <input type="text" placeholder="Номер тефону" name="phone" id="phone" ><br><br>
            <input type="button" id="button_send" value="Зберегти">
            </div>
            <br><br>
            <div id="messageShow" > </div>
</div>