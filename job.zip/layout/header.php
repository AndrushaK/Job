        <div id="logo">
        		<a href="#"><img height="58" width="50" src="images/favicon.ico" alt="" /></a>
            <h1><a href="#">Test PHP sites</a></h1>
            <h2>by Kotchuruba</h2>
        </div>